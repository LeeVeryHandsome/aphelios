#ifndef SHOW_H
#define SHOW_H
 
void draw_bar_chart(struct SeqQueue *q, WINDOW *win);

#endif
